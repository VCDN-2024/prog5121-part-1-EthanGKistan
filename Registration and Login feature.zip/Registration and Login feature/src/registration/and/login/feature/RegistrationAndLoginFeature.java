package registration.and.login.feature;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class RegistrationAndLoginFeature {
    String UserName;
    String Password;
    String FirstName;
    String LastName;
    private int loginAttempts; // Track the number of login attempts

    public RegistrationAndLoginFeature(String Username, String Password) {
        this.Password = Password;
        this.UserName = Username;
        this.loginAttempts = 0; // Initialize login attempts counter
    }

    public boolean CheckPasswordComplexity() {
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(Password);
        return matcher.matches();
    }

    public String registerUser() {
        while (true) {
            UserName = JOptionPane.showInputDialog(null, "Please enter your username:");
            Password = JOptionPane.showInputDialog(null, "Please enter your password:");
            FirstName = JOptionPane.showInputDialog(null, "Please enter your first name:");
            LastName = JOptionPane.showInputDialog(null, "Please enter your last name:");

            if (UserName.length() > 5 || !UserName.contains("_")) {
                JOptionPane.showMessageDialog(null, "Username does not meet minimum criteria. Please try again.");
                continue;
            }

            if (!CheckPasswordComplexity()) {
                JOptionPane.showMessageDialog(null, "Password does not meet minimum criteria. Please try again.");
                continue;
            }

            break;
        }

        return "Username and Password Successfully captured";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (enteredUsername.equals(UserName) && enteredPassword.equals(Password)) {
            return true;
        } else {
            loginAttempts++; // Increment login attempts counter
            return false;
        }
    }

    public String returnLoginStatus(boolean LoginStatus) {
        if (LoginStatus) {
            return "Welcome " + FirstName + " " + LastName;
        } else {
            return "Invalid Credentials";
        }
    }

    public String getUserName() {
        return UserName;
    }

    public static void main(String[] args) {
        System.out.println("""
                *ensure that the password contains at least one capital letter.
                *ensure that the password contains at least one number.
                *ensure that the password contains at least one special character.
                *ensure that the password does not contain whitespace.
                *ensure that the password must be at least 8 characters long.
                """);

        RegistrationAndLoginFeature user = new RegistrationAndLoginFeature("", "");

        JOptionPane.showMessageDialog(null, user.registerUser());

        int maxLoginAttempts = 3; // Maximum number of login attempts allowed

        boolean loginSuccessful = false;
        while (!loginSuccessful && user.loginAttempts < maxLoginAttempts) {
            String enteredUsername = JOptionPane.showInputDialog(null, "Please enter your username to login:");
            String enteredPassword = JOptionPane.showInputDialog(null, "Please enter your password to login:");

            loginSuccessful = user.loginUser(enteredUsername, enteredPassword);
            if (!loginSuccessful) {
                JOptionPane.showMessageDialog(null, "Invalid Credentials. Please try again.");
            }
        }

        if (!loginSuccessful) {
            JOptionPane.showMessageDialog(null, "Maximum login attempts reached. Exiting program.");
            System.exit(0); // Terminate the program
        }

        JOptionPane.showMessageDialog(null, user.returnLoginStatus(loginSuccessful));
    }
}
