package  registration.and.login.feature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class RegistrationAndLoginFeatureTest {

    private RegistrationAndLoginFeature user;

    @BeforeEach
    public void setUp() {
        user = new RegistrationAndLoginFeature("kyl_1", "Ch&&sec@ke99");
    }

    @Test
    public void testCheckPasswordComplexityValidPassword() {
        assertTrue(user.CheckPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexityInvalidPassword() {
        user.Password = "password";
        assertFalse(user.CheckPasswordComplexity());
    }

    @Test
    public void testCheckUsernameValidUsername() {
        assertTrue(user.UserName.length() > 5 && !user.UserName.contains("_"));
    }

    @Test
    public void testCheckUsernameInvalidUsername() {
        user.UserName = "kyle!!!!!!!";
        assertFalse(user.UserName.length() > 5 && !user.UserName.contains("_"));
    }

    @Test
    public void testRegisterUserValidUsernameAndPassword() {
        assertEquals(user.registerUser(), "Username and Password Successfully captured");
    }

    @Test
    public void testRegisterUserInvalidUsernameAndPassword() {
        user.UserName = "kyle!!!!!!!";
        user.Password = "password";
        assertNotEquals(user.registerUser(), "Username and Password Successfully captured");
    }

    @Test
    public void testLoginUserValidUsernameAndPassword() {
        assertTrue(user.loginUser("kyl_1", "Ch&&sec@ke99"));
    }

    @Test
    public void testLoginUserInvalidUsernameAndPassword() {
        assertFalse(user.loginUser("kyle!!!!!!!", "password"));
    }
}